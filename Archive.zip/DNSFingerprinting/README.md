The script "dns_fingerprinting.py" is developed to create DNS fingerprints for IoT Devices. Please install the required dependenices from the requirements.txt file before using. 


Usage: 

	sudo python3 dns_fingerprinting.py [-h] [--ip IP] [--date DATE] [--day] [--week] [--month] [--vendor]

Arguments:

    1. --ip: This argument is to be used if a specific IP address required to be analyzed. Format - 192.168.1.X. 
    2. --date: This is the Initial date from where the data will be analyzed. Format - YYYYMMDD.
    3. --day: Analyze PCAP files for only a day. 
    4. --week: Analyze PCAP files for a week.
    5. --month: Analyze PCAP files for a month. (This hasnt been tested yet)
    6. --vendor: This argument performs vendor level analysis on the IoT Devices. 



Note: 

    1. The --ip argument is optional. A device_dictionary is included in the code. 
    2. The --ip argument will not work with the vendor argument. 
    3. The code will automatically convert the IP address when switching subnets for analysis. 
    4. The complete analysis for all devices present in the device_dictionary for a week takes about a day and a half. 
    5. After the analysis is complete, a JSON file will be created in the directory. 
