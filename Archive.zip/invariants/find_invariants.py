import os
import re
import time
import openai
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--country', type=str, required=True)
args = parser.parse_args()

openai.api_key = "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"

regex_ipv4 = "(^192\.168\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$)"
regex_ipv6 = "(^([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])$)"
regex_mac = "(^(?:[0-9a-fA-F]:?){12}$)"
regex_mdns = "(_[a-zA-Z0-9\-\_]*\._(?:tcp|udp)\.local\.)" 
regex_mdns_2 = "(.*\._[a-zA-Z0-9\-\_]*\._(?:tcp|udp)\.local\.)" 
regex_local = "(\.local\.$)"

re_ipv4 = re.compile(regex_ipv4)
re_ipv6 = re.compile(regex_ipv6)
re_mac = re.compile(regex_mac)
re_mdns = re.compile(regex_mdns)
re_mdns_2 = re.compile(regex_mdns_2)
re_local = re.compile(regex_local)

devices = dict()

with open("/home/gong/invariants/"+args.country+".txt") as fobj:
    for row in fobj:
        if row.startswith("192.168.") and not row[:-1].endswith(".1"):
            devices[row[:-1]] = next(fobj)[2:-3].split("', '")

for ip, answers in devices.items():
    devices[ip] = list()
    for answer in answers:
        if answer != "DNS Ans ": 
            entry = answer[9:-2]
            if entry.startswith("["):# list of information
                details = entry[4:-3].split("\\', b\\'")
                devices[ip].append(', '.join([detail for detail in details]))
            elif entry.startswith("b\\'"):
                devices[ip].append(entry[3:-2])
            else:
                if entry != ip:
                    devices[ip].append(entry)

keys_to_be_deleted = list()

for ip, details in devices.items():
    if len(details) == 0:
        keys_to_be_deleted.append(ip)

for key in keys_to_be_deleted:
    del devices[key]

chatgpt_devices = dict()

for ip, details in devices.items():
    #print(ip)
    for detail in details: 
        if re.findall(re_ipv4, detail):
            pass
            #print(detail)
        elif re.findall(re_ipv6, detail):
            pass
            #print(detail)
        elif re.findall(re_mac, detail):
            pass
            #print(detail)
        elif re.findall(re_local, detail): 
            if re.findall(re_mdns, detail):
                if re.findall(re_mdns_2, detail):
                    #pass
                    info = ".".join(detail.split(".")[:-4])
                    if ip not in chatgpt_devices:
                        chatgpt_devices[ip] = list()
                        chatgpt_devices[ip].append(info)
                    else:
                        if info not in chatgpt_devices[ip]:
                            chatgpt_devices[ip].append(info)
            else:
                #pass
                info = detail[:-7]
                if ip not in chatgpt_devices:
                    chatgpt_devices[ip] = list()
                    chatgpt_devices[ip].append(info)
                else:
                    if info not in chatgpt_devices[ip]:
                        chatgpt_devices[ip].append(info)
        else:
            #pass
            if ip not in chatgpt_devices:
                chatgpt_devices[ip] = list()
                chatgpt_devices[ip].append(detail)
            else:
                if detail not in chatgpt_devices[ip]:
                    chatgpt_devices[ip].append(detail)

for ip, details in chatgpt_devices.items():
    print(ip)
    for detail in details:
        try: 
            message = [{"role": "user", "content": "Can you find the device's name and model from the following entry: " + detail}]
            chat = openai.ChatCompletion.create(
                model="gpt-3.5-turbo", messages=message
            )
            reply = chat.choices[0].message.content
            print("original: " + detail)
            print(f"ChatGPT: {reply}")
            time.sleep(35)
        except openai.error.APIError:
            pass
    print()
