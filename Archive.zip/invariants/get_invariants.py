import os
import json
import time
import openai
from collections import OrderedDict

openai.api_key = "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"
messages = []

list_aus_active = list()
list_aus_passive = list()
list_ind_active = list()
list_ind_passive = list()
devices_aus_active = list()
devices_aus_passive = list()
devices_ind_active = list()
devices_ind_passive = list()

folder_directory = "/Users/gong/Desktop/IoT_Lab/invariants"

for subfolder in os.listdir(os.path.join(folder_directory, "mDNS_invariants")):
    if subfolder.startswith("analysis_"):
        #print(subfolder)
        for file in os.listdir(os.path.join(folder_directory, "mDNS_invariants", subfolder)):
            if file.startswith("mdns_"):
                with open(os.path.join(folder_directory, "mDNS_invariants", subfolder, file)) as fobj:
                    data = json.loads(fobj.read())
                    for device, details in data.items():
                        details = OrderedDict(sorted(details.items(), key=lambda x:x[0]))
                        #print(device)
                        #print(details)
                        #print(type(details))
                        if file.startswith("mdns_aus_active"):
                            if device not in devices_aus_active: 
                                devices_aus_active.append(device)
                                list_aus_active.append({device:dict(details)})
                            else:
                                dev_a = list()
                                dev_ptr = list()
                                dev_srv = list()
                                dev_txt = list()
                                for elem in list_aus_active: 
                                    if device in elem.keys():
                                        dev1_details = elem[device]
                                        if 'A' in dev1_details:
                                            dev1_a = set([(k, str(v)) for k, v in dev1_details['A'][0].items()])
                                        if 'PTR' in dev1_details:
                                            dev1_ptr = set([(k, str(v)) for k, v in dev1_details['PTR'][0].items()])
                                        if 'SRV' in dev1_details:
                                            dev1_srv = set([(k, str(v)) for k, v in dev1_details['SRV'][0].items()])
                                        if 'TXT' in dev1_details:
                                            dev1_txt = set([(k, str(v)) for k, v in dev1_details['TXT'][0].items()])
                                dev2_details = dict(details)
                                if 'A' in dev2_details:
                                    #print(dev2_details['A'][0].items())
                                    dev2_a = set([(k, str(v)) for k, v in dev2_details['A'][0].items()])
                                    dev_a = list({a[0]: a[1]} for a in (dev1_a & dev2_a))
                                    #print(dev_a)
                                if 'PTR' in dev2_details:
                                    dev2_ptr = set([(k, str(v)) for k, v in dev2_details['PTR'][0].items()])
                                    dev_ptr = list({ptr[0]: ptr[1]} for ptr in (dev1_ptr & dev2_ptr))
                                    #print(dev_ptr)
                                if 'SRV' in dev2_details:
                                    dev2_srv = set([(k, str(v)) for k, v in dev2_details['SRV'][0].items()])
                                    dev_srv = list({srv[0]: srv[1]} for srv in (dev1_srv & dev2_srv))
                                    #print(dev_srv)
                                if 'TXT' in dev2_details:
                                    dev2_txt = set([(k, str(v)) for k, v in dev2_details['TXT'][0].items()])
                                    dev_txt = list({txt[0]: txt[1]} for txt in (dev1_txt & dev2_txt))
                                    #print(dev_txt)
                                dev = dict()
                                if dev_a:
                                    dev['A'] = dev_a
                                if dev_ptr:
                                    dev['PTR'] = dev_ptr
                                if dev_srv:
                                    dev['SRV'] = dev_srv
                                if dev_txt:
                                    dev['TXT'] = dev_txt
                                #print(dev)
                                for elem in list_aus_active:
                                    if device in elem.keys():
                                        elem[device] = dev
                                        
                        if file.startswith("mdns_aus_passive"): 
                            if device not in devices_aus_passive: 
                                devices_aus_passive.append(device)
                                list_aus_passive.append({device:details})
                            else: 
                                dev_a = list()
                                dev_ptr = list()
                                dev_srv = list()
                                dev_txt = list()
                                for elem in list_aus_passive: 
                                    if device in elem.keys():
                                        dev1_details = elem[device]
                                        if 'A' in dev1_details:
                                            dev1_a = set([(k, str(v)) for k, v in dev1_details['A'][0].items()])
                                        if 'PTR' in dev1_details:
                                            dev1_ptr = set([(k, str(v)) for k, v in dev1_details['PTR'][0].items()])
                                        if 'SRV' in dev1_details:
                                            dev1_srv = set([(k, str(v)) for k, v in dev1_details['SRV'][0].items()])
                                        if 'TXT' in dev1_details:
                                            dev1_txt = set([(k, str(v)) for k, v in dev1_details['TXT'][0].items()])
                                dev2_details = dict(details)
                                if 'A' in dev2_details:
                                    dev2_a = set([(k, str(v)) for k, v in dev2_details['A'][0].items()])
                                    dev_a = list({a[0]: a[1]} for a in (dev1_a & dev2_a))
                                if 'PTR' in dev2_details:
                                    dev2_ptr = set([(k, str(v)) for k, v in dev2_details['PTR'][0].items()])
                                    dev_ptr = list({ptr[0]: ptr[1]} for ptr in (dev1_ptr & dev2_ptr))
                                if 'SRV' in dev2_details:
                                    dev2_srv = set([(k, str(v)) for k, v in dev2_details['SRV'][0].items()])
                                    dev_srv = list({srv[0]: srv[1]} for srv in (dev1_srv & dev2_srv))
                                if 'TXT' in dev2_details:
                                    dev2_txt = set([(k, str(v)) for k, v in dev2_details['TXT'][0].items()])
                                    dev_txt = list({txt[0]: txt[1]} for txt in (dev1_txt & dev2_txt))
                                dev = dict()
                                if dev_a:
                                    dev['A'] = dev_a
                                if dev_ptr:
                                    dev['PTR'] = dev_ptr
                                if dev_srv:
                                    dev['SRV'] = dev_srv
                                if dev_txt:
                                    dev['TXT'] = dev_txt
                                for elem in list_aus_passive:
                                    if device in elem.keys():
                                        elem[device] = dev

                        if file.startswith("mdns_ind_active"): 
                            if device not in devices_ind_active: 
                                devices_ind_active.append(device)
                                list_ind_active.append({device:details})
                            else: 
                                dev_a = list()
                                dev_ptr = list()
                                dev_srv = list()
                                dev_txt = list()
                                for elem in list_ind_active: 
                                    if device in elem.keys():
                                        dev1_details = elem[device]
                                        if 'A' in dev1_details:
                                            dev1_a = set([(k, str(v)) for k, v in dev1_details['A'][0].items()])
                                        if 'PTR' in dev1_details:
                                            dev1_ptr = set([(k, str(v)) for k, v in dev1_details['PTR'][0].items()])
                                        if 'SRV' in dev1_details:
                                            dev1_srv = set([(k, str(v)) for k, v in dev1_details['SRV'][0].items()])
                                        if 'TXT' in dev1_details:
                                            dev1_txt = set([(k, str(v)) for k, v in dev1_details['TXT'][0].items()])
                                dev2_details = dict(details)
                                if 'A' in dev2_details:
                                    dev2_a = set([(k, str(v)) for k, v in dev2_details['A'][0].items()])
                                    dev_a = list({a[0]: a[1]} for a in (dev1_a & dev2_a))
                                if 'PTR' in dev2_details:
                                    dev2_ptr = set([(k, str(v)) for k, v in dev2_details['PTR'][0].items()])
                                    dev_ptr = list({ptr[0]: ptr[1]} for ptr in (dev1_ptr & dev2_ptr))
                                if 'SRV' in dev2_details:
                                    dev2_srv = set([(k, str(v)) for k, v in dev2_details['SRV'][0].items()])
                                    dev_srv = list({srv[0]: srv[1]} for srv in (dev1_srv & dev2_srv))
                                if 'TXT' in dev2_details:
                                    dev2_txt = set([(k, str(v)) for k, v in dev2_details['TXT'][0].items()])
                                    dev_txt = list({txt[0]: txt[1]} for txt in (dev1_txt & dev2_txt))
                                dev = dict()
                                if dev_a:
                                    dev['A'] = dev_a
                                if dev_ptr:
                                    dev['PTR'] = dev_ptr
                                if dev_srv:
                                    dev['SRV'] = dev_srv
                                if dev_txt:
                                    dev['TXT'] = dev_txt
                                for elem in list_ind_active:
                                    if device in elem.keys():
                                        elem[device] = dev

                        if file.startswith("mdns_ind_passive"): 
                            if device not in devices_ind_passive: 
                                devices_ind_passive.append(device)
                                list_ind_passive.append({device:details})
                            else: 
                                dev_a = list()
                                dev_ptr = list()
                                dev_srv = list()
                                dev_txt = list()
                                for elem in list_ind_passive: 
                                    if device in elem.keys():
                                        dev1_details = elem[device]
                                        if 'A' in dev1_details:
                                            dev1_a = set([(k, str(v)) for k, v in dev1_details['A'][0].items()])
                                        if 'PTR' in dev1_details:
                                            dev1_ptr = set([(k, str(v)) for k, v in dev1_details['PTR'][0].items()])
                                        if 'SRV' in dev1_details:
                                            dev1_srv = set([(k, str(v)) for k, v in dev1_details['SRV'][0].items()])
                                        if 'TXT' in dev1_details:
                                            dev1_txt = set([(k, str(v)) for k, v in dev1_details['TXT'][0].items()])
                                dev2_details = dict(details)
                                if 'A' in dev2_details:
                                    dev2_a = set([(k, str(v)) for k, v in dev2_details['A'][0].items()])
                                    dev_a = list({a[0]: a[1]} for a in (dev1_a & dev2_a))
                                if 'PTR' in dev2_details:
                                    dev2_ptr = set([(k, str(v)) for k, v in dev2_details['PTR'][0].items()])
                                    dev_ptr = list({ptr[0]: ptr[1]} for ptr in (dev1_ptr & dev2_ptr))
                                if 'SRV' in dev2_details:
                                    dev2_srv = set([(k, str(v)) for k, v in dev2_details['SRV'][0].items()])
                                    dev_srv = list({srv[0]: srv[1]} for srv in (dev1_srv & dev2_srv))
                                if 'TXT' in dev2_details:
                                    dev2_txt = set([(k, str(v)) for k, v in dev2_details['TXT'][0].items()])
                                    dev_txt = list({txt[0]: txt[1]} for txt in (dev1_txt & dev2_txt))
                                dev = dict()
                                if dev_a:
                                    dev['A'] = dev_a
                                if dev_ptr:
                                    dev['PTR'] = dev_ptr
                                if dev_srv:
                                    dev['SRV'] = dev_srv
                                if dev_txt:
                                    dev['TXT'] = dev_txt
                                for elem in list_ind_passive:
                                    if device in elem.keys():
                                        elem[device] = dev

'''
print("Australia Active: ")
print(list_aus_active)
print(len(list_aus_active))
print("India Active: ")
print(list_ind_active)
print(len(list_aus_passive))

print("Australia Passive: ")
print(list_aus_passive)
print(len(list_ind_active))
print("India Passive: ")
print(list_ind_passive)
print(len(list_ind_passive))
'''

intersection_active = set(devices_aus_active).intersection(set(devices_ind_active))
intersection_passive = set(devices_aus_passive).intersection(set(devices_ind_passive))

'''
print(intersection_active)
print(len(intersection_active))
print(intersection_passive)
print(len(intersection_passive))
'''

dict_common_aus_active = dict()
dict_common_aus_passive = dict()
dict_common_ind_active = dict()
dict_common_ind_passive = dict()


for device in list_aus_active:
    for key in device.keys():
        if key in intersection_active:
            dict_common_aus_active[key] = device[key]

for device in list_aus_passive:
    for key in device.keys():
        if key in intersection_passive:
            dict_common_aus_passive[key] = device[key]

for device in list_ind_active:
    for key in device.keys():
        if key in intersection_active:
            dict_common_ind_active[key] = device[key]           

for device in list_ind_passive:
    for key in device.keys():
        if key in intersection_passive:
            dict_common_ind_passive[key] = device[key]

'''
print(dict_common_aus_active)
print(dict_common_aus_passive)
print(dict_common_ind_active)
print(dict_common_ind_passive)
print()
print()
'''

for device in intersection_active:
    print(device)
    aus_active = dict_common_aus_active[device]
    ind_active = dict_common_ind_active[device]
    if 'A' in aus_active and 'A' in ind_active:
        message = [{"role": "user", "content": "Can you write a regular expression that matches " + str(aus_active['A'][0]) + " and " + str(ind_active['A'][0])}]
        chat = openai.ChatCompletion.create(
            model="gpt-3.5-turbo", messages=message
        )
        reply = chat.choices[0].message.content
        print("active A")
        print(aus_active['A'])
        print(ind_active['A'])
        print(f"ChatGPT: {reply}")
    time.sleep(25)
    if 'PTR' in aus_active and 'PTR' in ind_active:
        message = [{"role": "user", "content": "Can you write a regular expression that matches " + str(aus_active['PTR'][0]) + " and " + str(ind_active['PTR'][0])}]
        chat = openai.ChatCompletion.create(
            model="gpt-3.5-turbo", messages=message
        )
        reply = chat.choices[0].message.content
        print("active PTR")
        print(aus_active['PTR'])
        print(ind_active['PTR'])
        print(f"ChatGPT: {reply}")
    time.sleep(25)        
    if 'SRV' in aus_active and 'SRV' in ind_active:
        message = [{"role": "user", "content": "Can you write a regular expression that matches " + str(aus_active['SRV'][0]) + " and " + str(ind_active['SRV'][0])}]
        chat = openai.ChatCompletion.create(
            model="gpt-3.5-turbo", messages=message
        )
        reply = chat.choices[0].message.content
        print("active SRV")
        print(aus_active['SRV'])
        print(ind_active['SRV'])
        print(f"ChatGPT: {reply}")
    time.sleep(25)
    if 'TXT' in aus_active and 'TXT' in ind_active:
        message = [{"role": "user", "content": "Can you write a regular expression that matches " + str(aus_active['TXT'][0]) + " and " + str(ind_active['TXT'][0])}]
        chat = openai.ChatCompletion.create(
            model="gpt-3.5-turbo", messages=message
        )
        reply = chat.choices[0].message.content
        print("active TXT")
        print(aus_active['TXT'])
        print(ind_active['TXT'])
        print(f"ChatGPT: {reply}")
    time.sleep(25)
    print()
print()

for device in intersection_passive: 
    print(device)
    aus_passive = dict_common_aus_passive[device]
    ind_passive = dict_common_ind_passive[device]
    if 'A' in aus_passive and 'A' in ind_passive:
        message = [{"role": "user", "content": "Can you write a regular expression that matches " + str(aus_passive['A'][0]) + " and " + str(ind_passive['A'][0])}]
        chat = openai.ChatCompletion.create(
            model="gpt-3.5-turbo", messages=message
        )
        reply = chat.choices[0].message.content
        print("passive A")
        print(aus_passive['A'])
        print(ind_passive['A'])
        print(f"ChatGPT: {reply}")
    time.sleep(25)
    if 'PTR' in aus_passive and 'PTR' in ind_passive:
        message = [{"role": "user", "content": "Can you write a regular expression that matches " + str(aus_passive['PTR'][0]) + " and " + str(ind_passive['PTR'][0])}]
        chat = openai.ChatCompletion.create(
            model="gpt-3.5-turbo", messages=message
        )
        reply = chat.choices[0].message.content
        print("passive PTR")
        print(aus_passive['PTR'])
        print(ind_passive['PTR'])
        print(f"ChatGPT: {reply}")
    time.sleep(25)
    if 'SRV' in aus_passive and 'SRV' in ind_passive:
        message = [{"role": "user", "content": "Can you write a regular expression that matches " + str(aus_passive['SRV'][0]) + " and " + str(ind_passive['SRV'][0])}]
        chat = openai.ChatCompletion.create(
            model="gpt-3.5-turbo", messages=message
        )
        reply = chat.choices[0].message.content
        print("passive SRV")
        print(aus_passive['SRV'])
        print(ind_passive['SRV'])
        print(f"ChatGPT: {reply}")
    time.sleep(25)
    if 'TXT' in aus_passive and 'TXT' in ind_passive:
        message = [{"role": "user", "content": "Can you write a regular expression that matches " + str(aus_passive['TXT'][0]) + " and " + str(ind_passive['TXT'][0])}]
        chat = openai.ChatCompletion.create(
            model="gpt-3.5-turbo", messages=message
        )
        reply = chat.choices[0].message.content
        print("passive TXT")
        print(aus_passive['TXT'])
        print(ind_passive['TXT'])
        print(f"ChatGPT: {reply}")
    time.sleep(25)
    print()





