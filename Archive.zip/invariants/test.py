import os
import openai

openai.api_key = "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"

messages = []

message = input("User: ")
if message: 
    messages.append({"role": "user", "content": message})
    chat = openai.ChatCompletion.create(
        model="gpt-3.5-turbo", messages=messages
    )
    reply = chat.choices[0].message.content
    print(f"ChatGPT: {reply}")
    messages.append({"role": "assistant", "content": reply})


