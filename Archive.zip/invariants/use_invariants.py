import os
import re
import time
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--country', type=str, required=True)
args = parser.parse_args()

list_regex = list()
dict_regex = dict()

regex_dlink_dcs = "DCS-8526LH-[0-9a-zA-Z]*._dcp._tcp.local."
regex_dlink_dsh = "md=DSH-C310"
regex_ecobee3_lite = "md=ecobee3 lite"
regex_ecobee_switch = "md=ecobee Switch\+"
regex_amcrest_camera = "AMC[0-9a-zA-Z]{15}._http._tcp.local."
regex_meross_smart_garage = "md=MSG100"
regex_netatmo_weather_station = "md=Weather Station"
regex_xiaomi_robot_vacuum = "viomi-vacuum-v8_miio[0-9]*._miio._udp.local."
regex_samsung_wisenet_smartcam = "SNS-R0810W-SAMSUNG-[0-9a-zA-Z\-\ ]*._http._tcp.local."
regex_google_chromecast = "Chromecast-[0-9a-zA-Z]*._googlecast._tcp.local."
regex_google_nest_mini = "Google-Nest-Mini-[0-9a-zA-Z]*._googlecast._tcp.local."
regex_insignia_fire_tv = "amzn.dmgr:[0-9a-zA-Z\-\ ]{32}:xnVDMM\+4u1:[0-9]*._amzn-wplay._tcp.local."
regex_ecobee_1 = "_ecobee._tcp.local."
regex_ecobee_2 = "MFG=ecobee Inc."
regex_philips_hue_1 = "Philips Hue - [0-9a-zA-Z]*._hue._tcp.local."
regex_philips_hue_2 = "Philips Hue - [0-9a-zA-Z]*._hap._tcp.local."
regex_philips_hue_3 = "modelid=BSB002"
regex_philips_hue_4 = "md=BSB002"
regex_hp_officejet_1 = "HP OfficeJet Pro 6970 [\[\]0-9a-zA-Z]*._ipp._tcp.local."
regex_hp_officejet_2 = "HP OfficeJet Pro 6970 [\[\]0-9a-zA-Z]*._ipps._tcp.local."
regex_hp_officejet_3 = "HP OfficeJet Pro 6970 [\[\]0-9a-zA-Z]*._http._tcp.local."
regex_hp_officejet_4 = "ty=HP OfficeJet Pro 6970"
regex_hp_officejet_5 = "product=\(HP OfficeJet Pro 6970\)"
regex_google = "_googlezone._tcp.local."
regex_amazon_alexa = "_amzn-alexa._tcp.local."
regex_netatmo = "Netatmo"
regex_mediatek_soc = "mt7687"
regex_hisilicon_soc = "Hi3516A"

re_dlink_dcs = re.compile(regex_dlink_dcs)
list_regex.append(re_dlink_dcs)
dict_regex[re_dlink_dcs] = "D-Link DCS Camera"
re_dlink_dsh = re.compile(regex_dlink_dsh)
list_regex.append(re_dlink_dsh)
dict_regex[re_dlink_dsh] = "D-Link DSH Camera"
re_ecobee3_lite = re.compile(regex_ecobee3_lite)
list_regex.append(re_ecobee3_lite)
dict_regex[re_ecobee3_lite] = "Ecobee 3lite Thermostat"
re_ecobee_switch = re.compile(regex_ecobee_switch)
list_regex.append(re_ecobee_switch)
dict_regex[re_ecobee_switch] = "Ecobee Switch+"
re_amcrest_camera = re.compile(regex_amcrest_camera)
list_regex.append(re_amcrest_camera)
dict_regex[re_amcrest_camera] = "Amcrest Camera"
re_meross_smart_garage = re.compile(regex_meross_smart_garage)
list_regex.append(re_meross_smart_garage)
dict_regex[re_meross_smart_garage] = "Meross Garage Door Opener"
re_netatmo_weather_station = re.compile(regex_netatmo_weather_station)
list_regex.append(re_netatmo_weather_station)
dict_regex[re_netatmo_weather_station] = "Netatmo Weather Station"
re_xiaomi_robot_vacuum = re.compile(regex_xiaomi_robot_vacuum)
list_regex.append(re_xiaomi_robot_vacuum)
dict_regex[re_xiaomi_robot_vacuum] = "Xiaomi Robot Vacuum"
re_samsung_wisenet_smartcam = re.compile(regex_samsung_wisenet_smartcam)
list_regex.append(re_samsung_wisenet_smartcam)
dict_regex[re_samsung_wisenet_smartcam] = "Samsung Wisenet Smartcam"
re_google_chromecast = re.compile(regex_google_chromecast)
list_regex.append(re_google_chromecast)
dict_regex[re_google_chromecast] = "Google Chromecast"
re_google_nest_mini = re.compile(regex_google_nest_mini)
list_regex.append(re_google_nest_mini)
dict_regex[re_google_nest_mini] = "Google Nest Mini"
re_insignia_fire_tv = re.compile(regex_insignia_fire_tv)
list_regex.append(re_insignia_fire_tv)
dict_regex[re_insignia_fire_tv] = "Insignia Fire TV"
re_ecobee_1 = re.compile(regex_ecobee_1)
list_regex.append(re_ecobee_1)
dict_regex[re_ecobee_1] = "Ecobee"
re_ecobee_2 = re.compile(regex_ecobee_2)
list_regex.append(re_ecobee_2)
dict_regex[re_ecobee_2] = "Ecobee"
re_philips_hue_1 = re.compile(regex_philips_hue_1)
list_regex.append(re_philips_hue_1)
dict_regex[re_philips_hue_1] = "Philips Hue"
re_philips_hue_2 = re.compile(regex_philips_hue_2)
list_regex.append(re_philips_hue_2)
dict_regex[re_philips_hue_2] = "Philips Hue"
re_philips_hue_3 = re.compile(regex_philips_hue_3)
list_regex.append(re_philips_hue_3)
dict_regex[re_philips_hue_3] = "Philips Hue"
re_philips_hue_4 = re.compile(regex_philips_hue_4)
list_regex.append(re_philips_hue_4)
dict_regex[re_philips_hue_4] = "Philips Hue"
re_hp_officejet_1 = re.compile(regex_hp_officejet_1)
list_regex.append(re_hp_officejet_1)
dict_regex[re_hp_officejet_1] = "HP OfficeJet"
re_hp_officejet_2 = re.compile(regex_hp_officejet_2)
list_regex.append(re_hp_officejet_2)
dict_regex[re_hp_officejet_2] = "HP OfficeJet"
re_hp_officejet_3 = re.compile(regex_hp_officejet_3)
list_regex.append(re_hp_officejet_3)
dict_regex[re_hp_officejet_3] = "HP OfficeJet"
re_hp_officejet_4 = re.compile(regex_hp_officejet_4)
list_regex.append(re_hp_officejet_4)
dict_regex[re_hp_officejet_4] = "HP OfficeJet"
re_hp_officejet_5 = re.compile(regex_hp_officejet_5)
list_regex.append(re_hp_officejet_5)
dict_regex[re_hp_officejet_5] = "HP OfficeJet"
re_google = re.compile(regex_google)
list_regex.append(re_google)
dict_regex[re_google] = "Google"
re_amazon_alexa = re.compile(regex_amazon_alexa)
list_regex.append(re_amazon_alexa)
dict_regex[re_amazon_alexa] = "Amazon Alexa"
re_netatmo = re.compile(regex_netatmo)
list_regex.append(re_netatmo)
dict_regex[re_netatmo] = "Netatmo"
re_mediatek_soc = re.compile(regex_mediatek_soc)
list_regex.append(re_mediatek_soc)
dict_regex[re_mediatek_soc] = "Meross Garage Door Opener"
re_hisilicon_soc = re.compile(regex_hisilicon_soc)
list_regex.append(re_hisilicon_soc)
dict_regex[re_hisilicon_soc] = "Samsung Wisenet SmartCam"


devices = dict()

with open("/Users/gong/Desktop/IoT_Lab/invariants/"+args.country+".txt") as fobj:
    for row in fobj:
        if row.startswith("192.168.") and not row[:-1].endswith(".1"):
            devices[row[:-1]] = next(fobj)[2:-3].split("', '")

for ip, answers in devices.items():
    devices[ip] = list()
    for answer in answers:
        if answer != "DNS Ans ":
            entry = answer[9:-2]
            if entry.startswith("["):
                details = entry[4:-3].split("\\', b\\'")
                devices[ip].append(', '.join([detail for detail in details]))
            elif entry.startswith("b\\'"):
                devices[ip].append(entry[3:-2])
            else:
                if entry != ip:
                    devices[ip].append(entry)

keys_to_be_deleted = list()

for ip, details in devices.items():
    if len(details) == 0:
        keys_to_be_deleted.append(ip)

for key in keys_to_be_deleted:
    del devices[key]

results = dict()

for ip, details in devices.items():
    for detail in details:
        for regex in list_regex: 
            if re.findall(regex, detail):
                if ip not in results:
                    results[ip] = list() 
                    results[ip].append(dict_regex[regex])
                else:
                    if dict_regex[regex] not in results[ip]:
                        results[ip].append(dict_regex[regex])

print(results)
